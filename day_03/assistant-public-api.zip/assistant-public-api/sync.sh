mv ./assistant-public-api ./app
scp -p ./app root@171.244.51.79:/zserver/go-deploy/coteccons/bin